To test and run:
python3 graph.py

inside graph.py, X defined as collection of points!
