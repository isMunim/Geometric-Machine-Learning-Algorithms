#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 14 18:02:14 2018

@author: Mustafa Hajij
"""

from unionfind import *
import networkx as nx

class kruskalsalgorithm():
    def __init__(self,inputgraph):
        self.original_graph=inputgraph
        self.tree=nx.Graph()


    # uncomment the following function and start your implementation as described in lecture 2
    #def spanningtree(self):
        # PUT YOUR CODE HERE
